import { useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

function App() {
  const [reports, setReports] = useState([]);
  const [newReport, setNewReport] = useState({ lat: '', lng: '', note: '' });

  const addReport = () => {
    if (!newReport.lat || !newReport.lng || !newReport.note) return;
    setReports([...reports, newReport]);
    setNewReport({ lat: '', lng: '', note: '' });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'row', padding: 20, gap: 20 }}>
      <div style={{ flex: 2, height: '80vh' }}>
        <MapContainer center={[20.5937, 78.9629]} zoom={5} style={{ height: '100%', width: '100%' }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          {reports.map((r, i) => (
            <Marker position={[r.lat, r.lng]} key={i}>
              <Popup>{r.note}</Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <h2>New Report</h2>
        <input
          type="number"
          placeholder="Latitude"
          value={newReport.lat}
          onChange={(e) => setNewReport({ ...newReport, lat: parseFloat(e.target.value) })}
        />
        <input
          type="number"
          placeholder="Longitude"
          value={newReport.lng}
          onChange={(e) => setNewReport({ ...newReport, lng: parseFloat(e.target.value) })}
        />
        <input
          type="text"
          placeholder="Note"
          value={newReport.note}
          onChange={(e) => setNewReport({ ...newReport, note: e.target.value })}
        />
        <button onClick={addReport}>Add Report</button>
      </div>
    </div>
  );
}

export default App;